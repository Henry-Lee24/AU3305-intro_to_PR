运行方式：

可以看到PR_final.py文件245行的代码

```python
acc = test('data_test.mat', 'label_test.mat', model)  # 测试
```

将用于测试的标签文件的文件名改成label_test.mat后运行即可

